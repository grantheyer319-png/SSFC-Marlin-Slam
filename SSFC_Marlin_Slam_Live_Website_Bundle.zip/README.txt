SSFC LIVE SITE BUNDLE

Files included:
- index.html
- poster.png
- SSFC_Marlin_Slam_Rules_2026.pdf

How to go live for free:
1. Upload these files to Netlify Drop or GitHub Pages.
2. Keep all 3 files together in the same folder.
3. Open index.html after upload.

Notes:
- This version includes the poster and rules link.
- The registration form is currently a live demo front-end.
- To accept real entries, connect the form to Google Forms or Google Sheets.
